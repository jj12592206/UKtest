package stepDefinition;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utilsLayer.com.KnownCoordinates;
import utilsLayer.com.initialisation;

public class StepDefinition {
	
	@Given("Rover direction and positioning")
	public void rover_direction_and_positioning() {
		 boolean dir = initialisation.initialDirection();
		 boolean cor = initialisation.initialCoordinates();
		 Assert.assertEquals(cor, true);
		 Assert.assertEquals(dir, true);

		}

	@When("Move to mentioned coordinates")
	public void move_to_mentioned_coordinates() {
		//moving rover to some known coordinates and directions
		KnownCoordinates.moveToKownCord(5, 7, 'E');

	}

	@Then("Moves rover to users coordinate")
	public void moves_rover_to_users_coordinate() {
		KnownCoordinates obj4 = new KnownCoordinates();
	   // move rover to 5 5 coordinates
		KnownCoordinates.moveToKownCord(5, 7, 'E');
		

		// move rover to 1 2 N coordinates
		KnownCoordinates.moveToKownCord(1, 2, 'N');
			
		// move rover to LMLMLMLMM
		KnownCoordinates.moveToKownCord(1, 2, 'N');
		obj4.turnLeft();
		obj4.move();
		obj4.turnLeft();
		obj4.move();
		obj4.turnLeft();
		obj4.move();
		obj4.turnLeft();
		obj4.move();
		obj4.move();
	}

}
