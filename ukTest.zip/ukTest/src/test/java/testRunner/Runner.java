package testRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class) 
	@CucumberOptions( 
	 
	 features={"feature"}, 
	 glue= {"StepDefination"}, 
	 plugin= {"html:target/cucumber-htmlreport","json:target/json_output/cucumber.json","pretty:target/cucumber-pretty.txt", 
	 "junit:target/cucumber-results.xml"}, 
	 monochrome=true,
	 dryRun=true
	 ) 
	public class Runner {
	} 
