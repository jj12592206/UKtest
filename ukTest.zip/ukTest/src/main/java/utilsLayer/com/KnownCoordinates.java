package utilsLayer.com;

public class KnownCoordinates {
	int x = 0 ;
	int y = 0 ;
	char facing = 'N' ;
	public static void moveToKownCord(int x , int y,char facing) {
		KnownCoordinates obj2 = new KnownCoordinates();
		obj2.setPosition(x,y,facing);
	
	}
 public void setPosition( int x , int y, char facing) {
	this.x = x ;
	this.y = y ;
	this.facing = facing ;
 }
 
 public void move() {
	 if(facing == 'N') {
		 this.y=0;
	 }
	 else if(facing == 'E') {
		 this.x =0; 
	 }
	 else if (facing == 'S') {
		 this.y-- ;
	 }
	 else if(facing == 'W'){
		 this.x-- ;
		 
	 }
 }
 
 public void turnLeft() {
	 facing = (char) ((facing - '1') < 'N' ? 'W' : facing - '1') ;
 }
 
 public void turnRight() {
	 facing = (char) ((facing - '1') < 'W' ? 'N' : facing - '1') ;
 }
}
