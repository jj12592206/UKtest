package utilsLayer.com;


public class initialisation {
	public static int xcord = 0;
	public static int ycord = 0;
	public static char dirct = 'N';
public static boolean initialDirection() {
	if(dirct == 'N') {
		return true;
	}
	else {
	return false;
	}
}
public static boolean initialCoordinates() {
	if((xcord == 0) && (ycord == 0)) {
		return true;
	}
	else {
	return false;
	}
}
}
