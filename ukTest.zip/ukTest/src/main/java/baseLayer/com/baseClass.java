package baseLayer.com;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class baseClass {
	public static WebDriver driver;
	public static Properties prop;
	public baseClass() {
	prop = new Properties();
	try {
		FileInputStream f2 = new FileInputStream("C:\\Users\\Admin\\eclipse-workspace\\Maven3\\src\\main\\java\\configLayer\\com");
				prop.load(f2);
	}
	catch(FileNotFoundException e){
		e.printStackTrace();	
	}
	catch(IOException e) {
		e.printStackTrace();
	}
	}
	public static void initialStaring() {
		
		System.setProperty("Webdriver.chrome.Driver", "‪D:\\newchrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
	}
	
}
